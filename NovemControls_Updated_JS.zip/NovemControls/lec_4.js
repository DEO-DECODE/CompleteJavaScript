let arr=["ma", [4,"shyam"], {}];
console.log(arr[1][0]);
console.log(arr[1].indexOf(4));
